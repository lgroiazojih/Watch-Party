User: Taha (طاها). Prefers Persian/Farsi communication. First interaction 2026-08-02.
§
User: Taha (طاها). Language: Persian/Farsi — always respond in Persian. Has GitHub backup repo at github.com/lgroiazojih/hermes-backup for Hermes data backups.
§
User prefers communication in Persian (Farsi). Always respond in Farsi unless asked otherwise.
§
Name: Taha (طاها). Speaks Persian/Farsi — always respond in Farsi.
§
GitHub: lgroiazojih. Telegram username: TAHA148pro. Telegram group "🤫": chat_id -1004353556645.
§
Phone number: +989014742011 (recently purchased SIM, ported number). Had Telegram registration issue due to previous owner's account on that number.
§
User preference: Do NOT mask/redact data the user explicitly provided (phone numbers, emails, IDs) when it's needed for the task. Full data should appear in templates, emails, and outputs. Privacy masking of voluntarily-shared info frustrates the user.