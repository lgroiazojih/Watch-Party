---
name: hermes-backup
description: Backup Hermes data to GitHub with periodic cron scheduling.
tags: [backup, github, cron, devops, hermes]
triggers:
  - backup hermes
  - backup memory
  - save hermes data
  - periodic backup
  - cron backup
---

# Hermes Backup to GitHub

Back up critical Hermes Agent data to an external GitHub repository with automated scheduling.

## Critical Files to Backup

| Path | Contents |
|------|----------|
| `~/.hermes/memories/` | User memory files (memories.json + profile memories) |
| `~/.hermes/skills/` | Installed and custom skills |
| `~/.hermes/config.yaml` | Main Hermes configuration |
| `~/.hermes/SOUL.md` | Agent personality/identity |
| `~/.hermes/cron/` | Scheduled job definitions |
| `~/.hermes/sessions/` | Session history (sessions.json) |
| `~/.hermes/state.db` | Application state database |
| `~/.hermes/kanban.db` | Kanban board data |
| `~/.hermes/auth.json` | Authentication tokens |
| `~/.hermes/channel_directory.json` | Channel routing config |
| `~/.hermes/gateway_state.json` | Gateway state |

## Setup Pattern

### 1. Create Backup Script

Place in `~/.hermes/scripts/backup-to-github.sh`:

```bash
#!/bin/bash
set -euo pipefail

HERMES_DIR="$HOME/.hermes"
BACKUP_REPO_DIR="/tmp/hermes-backup-repo"
REPO_URL="https://<TOKEN>@github.com/<OWNER>/<REPO>.git"
TIMESTAMP=$(date '+%Y-%m-%d_%H-%M-%S')
BACKUP_FILE="hermes-backup-${TIMESTAMP}.tar.gz"

cd "$HERMES_DIR"

# Create archive of critical files
tar -czf "/tmp/${BACKUP_FILE}" memories skills config.yaml SOUL.md cron sessions state.db kanban.db auth.json channel_directory.json gateway_state.json 2>/dev/null || true

# Clone or update repo
if [ -d "$BACKUP_REPO_DIR/.git" ]; then
    cd "$BACKUP_REPO_DIR"
    git fetch origin 2>/dev/null || true
    git reset --hard origin/main 2>/dev/null || git reset --hard origin/master 2>/dev/null || true
else
    rm -rf "$BACKUP_REPO_DIR"
    git clone "$REPO_URL" "$BACKUP_REPO_DIR"
    cd "$BACKUP_REPO_DIR"
fi

# Copy archive
cp "/tmp/${BACKUP_FILE}" ./

# Keep only last 10 backups
ls -t hermes-backup-*.tar.gz 2>/dev/null | tail -n +11 | xargs -r rm -f

# Commit and push
git add -A
if ! git diff --cached --quiet; then
    git config user.email "hermes-backup@bot.local"
    git config user.name "Hermes Backup Bot"
    git commit -m "backup: ${TIMESTAMP}"
    git push origin HEAD
fi

rm -f "/tmp/${BACKUP_FILE}"
```

### 2. Create Cron Job

Use `cronjob` tool with `no_agent=True` for script-only execution:

```
cronjob(action='create', 
       name='hermes-backup',
       schedule='every 12h',
       script='backup-to-github.sh',  # RELATIVE to ~/.hermes/scripts/
       no_agent=True,
       deliver='origin')
```

## Pitfalls

1. **Script path must be relative**: Cron jobs with `no_agent=True` require `script` to be just the filename (e.g., `backup-to-github.sh`), not an absolute path. The system resolves it relative to `~/.hermes/scripts/`.

2. **HTTPS for token auth**: When port 22 is closed, use HTTPS with embedded token: `https://<TOKEN>@github.com/...`

3. **Archive only existing files**: Use `tar ... 2>/dev/null || true` to skip missing files gracefully.

4. **Prune old backups**: Keep last 10-20 backups to avoid repo bloat. Use `ls -t | tail -n +N | xargs rm -f`.

5. **Git config required**: Set `user.email` and `user.name` before committing in CI-like environments.

6. **$HOME vs actual path**: The cron environment may resolve `~/.hermes/scripts/` to a different path than the foreground shell (e.g., `/data/.hermes/scripts/` vs `/root/.hermes/scripts/`). Always verify the script exists at the cron-resolved path before scheduling.

## Restoration

To restore from backup:
```bash
cd /tmp
tar -xzf hermes-backup-YYYY-MM-DD_HH-MM-SS.tar.gz
cp -r memories skills config.yaml SOUL.md ~/.hermes/
# For databases, stop hermes first, then copy
cp state.db kanban.db ~/.hermes/
```
