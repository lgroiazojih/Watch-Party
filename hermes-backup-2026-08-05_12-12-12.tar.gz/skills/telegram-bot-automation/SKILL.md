---
name: telegram-bot-automation
description: "Telegram bots: chat_id discovery, messaging, scheduling."
tags: [telegram, bot, automation]
triggers:
  - telegram bot
  - create bot
  - send telegram message
---

# Telegram Bot Automation

Create Telegram bots that send messages on schedule.

## Key Requirements

1. Bot token from @BotFather
2. Chat ID must be discovered via getUpdates
3. Bot must be in group before sending

## Chat ID Format

Supergroup IDs require -100 prefix: -1004353556645 (not 1004353556645).

## Complete Example: Meow Bot

```python
#!/usr/bin/env python3
import time, requests, random

BOT_TOKEN = "YOUR_TOKEN"
CHAT_ID = "-100XXXXXXXXXX"  # Must include -100 prefix for supergroups
INTERVAL = 300  # 5 minutes

MEOWS = ["میو", "میو میو"]

def send_meow():
    msg = random.choice(MEOWS)
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    try:
        r = requests.post(url, json={"chat_id": CHAT_ID, "text": msg})
        if r.status_code == 200:
            print(f"[OK] Sent: {msg}")
        else:
            print(f"[ERR] {r.status_code}: {r.text}")
    except Exception as e:
        print(f"[ERR] {e}")

if __name__ == "__main__":
    print("Bot started!")
    while True:
        send_meow()
        time.sleep(INTERVAL)
```

Run with `terminal(background=True)` and `notify_on_complete=False`.

## Cron Job Pattern (no_agent)

For simple script execution without LLM:
```
cronjob(action='create',
       name='my-bot',
       schedule='every 5m',
       script='my-script.py',  # RELATIVE to ~/.hermes/scripts/
       no_agent=True,
       deliver='origin')
```

## Pitfalls

- **-100 prefix required**: Supergroup IDs must start with -100 (e.g., -1004353556645, not 1004353556645)
- **Bot must receive first**: Bot must receive a message before it can send to group; use getUpdates to verify
- **Script path relative**: Cron jobs with no_agent=True use filename only, resolved relative to ~/.hermes/scripts/
- **Stop background bots**: Use `process(action='kill', session_id=...)` to stop running bots
- **Never commit tokens**: Keep tokens in scripts, not in public repos
- **Port 22 closed?**: Use HTTPS with embedded token: `https://TOKEN@github.com/...`
- **Telegram Rate Limits (429)**: Sending too frequently triggers "Too Many Requests" errors. Safe intervals: 10-15 seconds minimum for groups, 30+ seconds for safety. The 1-second interval will cause rate limiting and potential bot bans.
