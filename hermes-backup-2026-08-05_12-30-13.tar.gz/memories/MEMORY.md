Hermes backup cron job (dfd073bff472): every 12h, script backup-to-github.sh, pushes to github.com/lgroiazojih/hermes-backup.
§
Taha's setup: Windows PC (no Bluetooth), Samsung phone. Interested in Samsung Multi Control. GitHub backup repo: lgroiazojih/hermes-backup.
§
Timezone: Taha is in IRST (Iran Standard Time, UTC+3:30). Cron schedules must be converted from Iran time to UTC.