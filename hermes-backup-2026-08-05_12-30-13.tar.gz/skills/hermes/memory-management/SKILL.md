---
name: memory-management
description: "Store, correct, and remove user data in Hermes memory."
tags: [memory, data-management, user-profile]
---

# Memory Management

How to store, correct, and remove data in Hermes memory and user-profile stores.

## Core Principles

1. **Accuracy first** — Never store unverified claims. If unsure, don't store.
2. **Thorough removal** — When user says "forget X", remove from BOTH `memory` AND `user` targets in one pass.
3. **No tombstones** — Do NOT add "REMOVED per user request" markers. Just delete cleanly.
4. **One-pass execution** — Use `operations` batch to handle multiple removals atomically. Don't make the user repeat themselves.

## Memory Tool API Patterns

### Removing entries
- `remove` action requires `old_text` — a **short unique substring** of the entry, NOT the full text.
- Use `operations` batch for multiple changes: `[{"action": "remove", "old_text": "..."}, ...]`
- If unsure which target holds the data, check both `memory` and `user`.

### Replacing entries
- `replace` action also requires `old_text` as the unique substring to find.
- The `content` field is the full new entry text.

### Adding entries
- Use `add` action with `content` and `target`.
- Keep entries compact and factual.

## Removal Checklist

When user requests data removal:

```
□ Identify ALL entries to remove (search both memory + user targets)
□ Use operations batch to remove them all in one call
□ Do NOT add replacement "removed" notes
□ Confirm what was removed in your response
```

## Pitfalls

- **PITFALL**: `remove` without `old_text` fails silently with a confusing error. Always pass `old_text`.
- **PITFALL**: Removing from only one target when data exists in both `memory` and `user`. Always check both.
- **PITFALL**: Adding "REMOVED" marker entries instead of just deleting. This wastes char budget and clutters memory.
- **PITFALL**: Storing sensitive data (phone numbers, chat IDs, tokens) without considering if the user might want it removed later. Prefer storing references over raw sensitive values.
