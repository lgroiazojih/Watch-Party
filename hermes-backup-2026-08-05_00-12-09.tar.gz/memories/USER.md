User: Taha (طاها). Prefers Persian/Farsi communication. First interaction 2026-08-02.
§
User: Taha (طاها). Language: Persian/Farsi — always respond in Persian. Has GitHub backup repo at github.com/lgroiazojih/hermes-backup for Hermes data backups.
§
User prefers communication in Persian (Farsi). Always respond in Farsi unless asked otherwise.
§
Name: Taha (طاها). Speaks Persian/Farsi — always respond in Farsi.
§
GitHub: lgroiazojih. Telegram username: TAHA148pro. Telegram group "🤫": chat_id -1004353556645.
§
User: Taha (طاها). Location: Iran. Language: Persian/Farsi. Platform: Telegram. Communicates casually, expects quick practical answers. Uses VPN (cannot disable it). Interested in Samsung Galaxy Book features on non-Samsung PC. Has GitHub repo lgroiazojih/hermes-backup for backups. Telegram group chat_id: -1004353556645. Bot: @MioMioCatBot. Has difficulty with my.telegram.org (persistent ERROR, possibly Iran-related).
§
User name: Taha (طاها). Communicates in Persian/Farsi. Based in Iran (needs VPN for internet access, cannot disable VPN).
§
User: Taha (طاها), speaks Persian (Farsi), based in Iran. Prefers concise responses. Communicates via Telegram.