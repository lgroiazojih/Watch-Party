---
name: code-security-audit
description: "Analyze scripts for security issues, malware, backdoors."
tags: [security, audit, malware, code-review, powershell, python]
triggers:
  - security audit
  - check for malware
  - analyze script safety
  - is this code safe
  - security review
---

# Code Security Audit

Analyze scripts and code for security issues, malware, backdoors, and suspicious behavior.

## Audit Checklist

### 1. Network Activity
- [ ] URLs/domains contacted (are they legitimate?)
- [ ] Data sent to external servers
- [ ] Reverse shells, sockets, listeners
- [ ] Firewall rules or port openings

### 2. System Modifications
- [ ] Registry changes (Windows)
- [ ] System files modified
- [ ] Scheduled tasks created
- [ ] Services installed/modified
- [ ] Environment variables changed

### 3. Data Handling
- [ ] Files read/written
- [ ] Credentials or passwords accessed
- [ ] Data exfiltration patterns
- [ ] Telemetry or analytics

### 4. Code Patterns
- [ ] Obfuscated or encoded code
- [ ] Dynamic code execution (eval, exec, Invoke-Expression)
- [ ] Anti-analysis techniques
- [ ] Hidden functionality

### 5. Destructive Operations
- [ ] File deletion
- [ ] System restore points modified
- [ ] Boot records changed

## PowerShell-Specific Checks

```bash
# Suspicious network calls
grep -n -i "Invoke-WebRequest\|Invoke-RestMethod\|WebClient\|Net.Sockets" FILE.ps1

# Registry modifications
grep -n -i "Set-ItemProperty\|New-ItemProperty\|reg add" FILE.ps1

# Scheduled tasks
grep -n -i "ScheduledTask\|Register-ScheduledTask" FILE.ps1

# Services
grep -n -i "sc\.exe\|New-Service\|Win32_Service" FILE.ps1

# Code execution
grep -n -i "IEX\|Invoke-Expression\|Start-Process" FILE.ps1

# File operations
grep -n -i "ReadAllBytes\|WriteAllBytes\|Remove-Item.*-Recurse" FILE.ps1

# Credentials
grep -n -i "Credential\|Password\|SecureString" FILE.ps1

# Telemetry/analytics
grep -n -i "telemetry\|analytics\|tracking" FILE.ps1

# Firewall
grep -n -i "Firewall\|Netsh\|OpenPort" FILE.ps1
```

## Python-Specific Checks

```bash
# Suspicious imports
grep -n -i "import socket\|import subprocess\|import os\|eval\|exec\|__import__" FILE.py

# Network activity
grep -n -i "requests\.\|urllib\|http\.client\|socket\." FILE.py

# File operations
grep -n -i "open(\|os\.remove\|shutil\.rmtree" FILE.py

# Code execution
grep -n -i "eval(\|exec(\|subprocess\|os\.system\|os\.popen" FILE.py
```

## Risk Assessment

| Finding | Risk Level | Action |
|---------|-----------|--------|
| Connects to known legitimate services | Low | Note |
| Modifies system files | Medium | Document |
| Requires admin/root | Medium | Justify |
| Creates scheduled tasks | Medium | Document |
| Obfuscated code | High | Investigate |
| Connects to unknown domains | High | Investigate |
| Reverse shell patterns | Critical | Block |
| Keylogger patterns | Critical | Block |

## Report Template

```markdown
# Security Audit Report — [Script Name]

## Summary
- **File:** [path]
- **Lines:** [count]
- **Risk Level:** [Low/Medium/High/Critical]

## Findings

### Network Activity
[Details]

### System Modifications
[Details]

### Data Handling
[Details]

### Code Patterns
[Details]

## Verdict
[Safe/Unsafe/Conditional]

## Recommendations
[Actions to take]
```

## Pitfalls

- **Don't assume malicious intent**: Many legitimate tools modify systems (installers, drivers, etc.)
- **Context matters**: Admin access is normal for installers, not for simple scripts
- **Check the source**: Open source code can be audited; precompiled binaries cannot
- **Test mode first**: Many tools have test/dry-run modes — use them
- **Backup before testing**: Always backup critical data before running untrusted scripts
