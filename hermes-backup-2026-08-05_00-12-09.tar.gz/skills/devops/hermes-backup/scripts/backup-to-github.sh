#!/bin/bash
# Hermes Backup Script - Backs up critical data to GitHub
# Usage: Place in ~/.hermes/scripts/backup-to-github.sh
# Then schedule via cronjob with no_agent=True

set -euo pipefail

# ── Config ──────────────────────────────────────────────
HERMES_DIR="$HOME/.hermes"
BACKUP_REPO_DIR="/tmp/hermes-backup-repo"
REPO_URL="https://<TOKEN>@github.com/<OWNER>/<REPO>.git"
TIMESTAMP=$(date '+%Y-%m-%d_%H-%M-%S')
BACKUP_FILE="hermes-backup-${TIMESTAMP}.tar.gz"

# ── Colors ──────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log() { echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date '+%H:%M:%S')] WARN:${NC} $1"; }
err() { echo -e "${RED}[$(date '+%H:%M:%S')] ERROR:${NC} $1"; }

# ── Step 1: Create temp backup archive ──────────────────
log "📦 Starting Hermes backup..."

TEMP_DIR=$(mktemp -d)
ARCHIVE_PATH="${TEMP_DIR}/${BACKUP_FILE}"

# Critical directories and files to backup
BACKUP_ITEMS=(
    "memories"
    "skills"
    "config.yaml"
    "SOUL.md"
    "cron"
    "sessions"
    "state.db"
    "kanban.db"
    "auth.json"
    "channel_directory.json"
    "gateway_state.json"
)

cd "$HERMES_DIR"

# Build tar command with only existing items
TAR_ARGS=()
for item in "${BACKUP_ITEMS[@]}"; do
    if [ -e "$item" ]; then
        TAR_ARGS+=("$item")
        log "  ✅ $item"
    else
        warn "  ⚠️  $item not found, skipping"
    fi
done

if [ ${#TAR_ARGS[@]} -eq 0 ]; then
    err "No files found for backup!"
    exit 1
fi

tar -czf "$ARCHIVE_PATH" "${TAR_ARGS[@]}"
ARCHIVE_SIZE=$(du -h "$ARCHIVE_PATH" | cut -f1)
log "📦 Archive created: ${BACKUP_FILE} (${ARCHIVE_SIZE})"

# ── Step 2: Clone or update repo ────────────────────────
log "🔄 Preparing repository..."

if [ -d "$BACKUP_REPO_DIR/.git" ]; then
    cd "$BACKUP_REPO_DIR"
    git fetch origin 2>/dev/null || true
    git reset --hard origin/main 2>/dev/null || git reset --hard origin/master 2>/dev/null || true
    log "  📂 Repository updated"
else
    rm -rf "$BACKUP_REPO_DIR"
    git clone "$REPO_URL" "$BACKUP_REPO_DIR" 2>/dev/null
    cd "$BACKUP_REPO_DIR"
    log "  📂 Repository cloned"
fi

# ── Step 3: Copy archive to repo ────────────────────────
cp "$ARCHIVE_PATH" "./"
log "📁 Archive copied to repository"

# ── Step 4: Cleanup old backups (keep last 10) ──────────
ls -t hermes-backup-*.tar.gz 2>/dev/null | tail -n +11 | xargs -r rm -f
REMAINING=$(ls hermes-backup-*.tar.gz 2>/dev/null | wc -l)
log "🧹 Remaining backups: ${REMAINING}"

# ── Step 5: Commit and push ─────────────────────────────
git add -A
if git diff --cached --quiet; then
    log "ℹ️  No changes to commit"
else
    git config user.email "hermes-backup@bot.local"
    git config user.name "Hermes Backup Bot"
    git commit -m "🔄 backup: ${TIMESTAMP}" --quiet
    git push origin HEAD --quiet
    log "✅ Backup uploaded successfully! (${TIMESTAMP})"
fi

# ── Cleanup ─────────────────────────────────────────────
rm -rf "$TEMP_DIR"
log "🏁 Backup complete!"
